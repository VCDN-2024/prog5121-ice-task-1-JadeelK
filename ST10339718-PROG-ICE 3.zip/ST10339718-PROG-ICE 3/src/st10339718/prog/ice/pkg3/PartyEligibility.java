package st10339718.prog.ice.pkg3;

import javax.swing.JOptionPane;
 
public class PartyEligibility {
   public static void main(String[] args) {
       String ageInput = JOptionPane.showInputDialog("Enter your age:");
       int age = Integer.parseInt(ageInput);
 
       if (age < 18) {
           JOptionPane.showMessageDialog(null, "You are denied entry. You are younger than 18.");
       } else if (age >= 35) {
           JOptionPane.showMessageDialog(null, "You are denied entry. You are 35 or older.");
       } else {
           String genderInput = JOptionPane.showInputDialog("Enter your gender (male or female):");
           String gender = genderInput.toLowerCase();
 
           switch (gender) {
               case "female":
                   JOptionPane.showMessageDialog(null, "You are allowed entry. Entry is free for females.");
                   break;
               case "male":
                   String groupSizeInput = JOptionPane.showInputDialog("Enter the number of guests in your group:");
                   int groupSize = Integer.parseInt(groupSizeInput);
                   int price = groupSize * 10;
                   JOptionPane.showMessageDialog(null, "You are allowed entry. The price for your group is R" + price + ".");
                   break;
               default:
                   JOptionPane.showMessageDialog(null, "Invalid gender input. Please enter 'male' or 'female'.");
                   break;
           }
       }
   }
}
